---
name: Kinetic Growth
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#434840'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#737970'
  outline-variant: '#c3c8be'
  surface-tint: '#476645'
  primary: '#09260b'
  on-primary: '#ffffff'
  primary-container: '#1f3c1f'
  on-primary-container: '#86a781'
  inverse-primary: '#add0a7'
  secondary: '#4f6600'
  on-secondary: '#ffffff'
  secondary-container: '#c9f25a'
  on-secondary-container: '#546d00'
  tertiary: '#381423'
  on-tertiary: '#ffffff'
  tertiary-container: '#512938'
  on-tertiary-container: '#c68fa1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c9ecc2'
  primary-fixed-dim: '#add0a7'
  on-primary-fixed: '#042107'
  on-primary-fixed-variant: '#304e2f'
  secondary-fixed: '#c9f25a'
  secondary-fixed-dim: '#add540'
  on-secondary-fixed: '#161f00'
  on-secondary-fixed-variant: '#3b4d00'
  tertiary-fixed: '#ffd9e3'
  tertiary-fixed-dim: '#f1b7c9'
  on-tertiary-fixed: '#320f1e'
  on-tertiary-fixed-variant: '#653a49'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.02em
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 60px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style

The brand personality is authoritative yet energetic, positioning the agency as a high-performance partner that balances strategic maturity with modern agility. The UI should evoke a sense of calculated growth, precision, and executive-level quality.

The chosen style is **Minimalism** blended with **Corporate/Modern** aesthetics. It utilizes heavy whitespace to allow data and results to breathe, while the high-contrast "Lime Green" serves as a kinetic spark against the "Dark Green" and "Black" foundation. This creates a visual metaphor for lighting up opportunities and driving conversion. Photography should be editorial and high-end, utilizing grayscale filters for supporting imagery to ensure that the accent color and key performance metrics remain the focal point of the user journey.

## Colors

This design system employs a sophisticated, high-contrast palette designed to direct the eye toward action and success metrics. 

- **Primary (Dark Green):** Used for deep backgrounds, primary navigation blocks, and high-level containers to establish authority.
- **Accent (Lime Green):** Reserved exclusively for high-priority CTAs, conversion points, and highlighting positive growth trends.
- **Neutrals:** A range of grays manages the information hierarchy. **Text Gray** is used for secondary body copy to reduce eye strain, while **Dark Charcoal** provides a softer alternative to pure black for deep text elements.
- **Backgrounds:** The primary interface uses pure **White** to maximize whitespace impact, with **Light Gray** used for subtle section differentiation.

## Typography

The typography strategy leverages two distinct sans-serifs to balance personality with readability. 

**Plus Jakarta Sans** is the voice of the agency—used for all headings. It is set in Bold (700) for primary headlines to convey strength and Semi-bold (600) for subheadings to maintain a clear hierarchy. Large display sizes utilize tighter letter spacing to create a modern, editorial feel.

**Inter** handles the functional heavy lifting. Its neutral, systematic nature ensures that long-form case studies and data points are highly legible. Labels and small badges should use Inter Semi-bold with increased letter spacing and uppercase styling to provide a crisp, professional "metadata" look.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model for desktop to ensure a controlled, high-end presentation, transitioning to a fluid model for mobile devices. 

- **Grid:** A 12-column grid is used for desktop (1280px max width). Elements should span 4, 6, or 12 columns to maintain a clean, symmetrical rhythm.
- **Whitespace:** A generous "Section Gap" of 120px is used between major content blocks to emphasize a premium feel. 
- **Rhythm:** All margins and paddings are derived from an 8px base unit. 
- **Mobile Adaption:** On mobile, margins reduce to 20px, and section gaps compress to 64px. Multi-column layouts should reflow to a single stack, prioritizing the most critical "result" or "CTA" at the top of each container.

## Elevation & Depth

This design system uses a "Flat-Plus" approach where depth is conveyed through **Tonal Layers** and **Subtle Shadows** rather than heavy gradients.

- **Surface Tiers:** Backgrounds are white, while card elements or distinct sections use Light Gray (#F5F5F5). 
- **Shadows:** Use extra-diffused, low-opacity shadows (e.g., 0px 4px 20px rgba(0, 0, 0, 0.05)) only when an element is interactive or needs to float above the primary surface.
- **Hover Transitions:** Interactive elements should employ a subtle "Lift" effect—moving 4px upward and slightly deepening the shadow—to provide immediate tactile feedback. 
- **Outlines:** Use 1px borders in Medium Gray (#E0E0E0) for containers that require structural definition without the weight of a shadow.

## Shapes

The shape language is modern and approachable. The roundedness is set to Level 2 (Rounded), which translates to an 8px radius for standard components like input fields and small buttons, scaling up to 16px or 20px for large cards and feature containers.

This specific range (8-20px) creates a professional look that avoids the clinical feel of sharp corners while remaining more serious and "business-oriented" than fully pill-shaped elements. Circular shapes are reserved exclusively for icon buttons or avatars.

## Components

### Buttons
- **Primary:** Background in Lime Green (#B8E04A), text in Black (#111111). Bold weight.
- **Secondary:** Background in Dark Green (#1F3C1F), text in White (#FFFFFF).
- **Ghost:** No background, 1px border in Dark Green or White, depending on surface.

### Cards
- White background with a 1px Medium Gray border or a very soft shadow. 
- Internal padding should be generous (minimum 32px).
- Photography within cards should feature the grayscale filter by default, transitioning to full color only on hover.

### Input Fields & Controls
- **Inputs:** Light Gray (#F5F5F5) background, 8px corner radius, with a 1px border that turns Dark Green on focus.
- **Badges:** Small, pill-shaped tags using Lime Green backgrounds with Black text to highlight "New" or "Hot" services.

### Imagery
- **Hero Photography:** Full color, high-saturation, professional.
- **Supporting Photography:** Apply a 0% saturation grayscale filter with high contrast. This ensures that UI elements and Lime Green accents stand out as the primary "life" of the page.

### Interactive Elements
- All links should have a subtle color transition from Text Gray to Dark Green.
- Icons should be minimal, geometric line icons with a consistent 2px stroke weight.